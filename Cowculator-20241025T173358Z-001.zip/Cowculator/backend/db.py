# Database connection logic with PyODBC 
