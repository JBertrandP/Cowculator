# Configuration files (e.g., DB connection strings) 
