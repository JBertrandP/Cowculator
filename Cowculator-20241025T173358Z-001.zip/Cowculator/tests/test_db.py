# Unit tests for database interactions 
